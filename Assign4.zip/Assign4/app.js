// app.js
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
 
const fetch = require('node-fetch');
// Функция для получения курсов валют
// Функция для получения курсов валют
async function getCurrencyRates() {
    try {
        const response = await fetch('https://api.exchangerate-api.com/v4/latest/KZT');
        const data = await response.json();

        // Получение курсов валют
        const usdRate = data.rates.USD;
        const rubRate = data.rates.RUB;
        const eurRate = data.rates.EUR; // Получаем курс евро

        // Вычисление обратного курса
        const usdReverse = 1 / usdRate;
        const rubReverse = 1 / rubRate;
        const eurReverse = 1 / eurRate; // Вычисляем обратный курс евро

        return {
            usd: usdRate,
            rub: rubRate,
            eur: eurRate, // Передаем курс евро на страницу
            usdReverse: usdReverse.toFixed(2),
            rubReverse: rubReverse.toFixed(2),
            eurReverse: eurReverse.toFixed(2) // Передаем обратный курс евро на страницу
        };
    } catch (error) {
        console.error('Error fetching currency rates:', error);
        return null;
    }
}

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/user_registration');
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// Middleware для проверки аутентификации
function requireLogin(req, res, next) {
    if (req.session && req.session.userId) { // Проверяем, есть ли у пользователя сессия
        return next(); // Если сессия есть, пропускаем запрос дальше
    } else {
        return res.redirect('/login'); // Если сессии нет, перенаправляем на страницу входа
    }
}

const session = require('express-session');

app.use(session({
    secret: 'secret-key', // Секретный ключ для подписи сессионных куки
    resave: false,
    saveUninitialized: true
}));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

// Define user schema
const userSchema = new mongoose.Schema({
    username: { type: String, unique: true },
    password: String,
    firstName: String,
    lastName: String,
    age: Number,
    email: String,
    gender: String,
    role: { type: String, default: 'user' }, // Add role field with default value 'user'
    createdAt: { type: Date, default: Date.now }
});
// news schema
const newsSchema = new mongoose.Schema({
    title: String,
    content: String,
    createdAt: { type: Date, default: Date.now }
});

const News = mongoose.model('News', newsSchema);


// Hash password before saving
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) {
        return next();
    }
    try {
        const hashedPassword = await bcrypt.hash(this.password, 10);
        this.password = hashedPassword;
        next();
    } catch (error) {
        next(error);
    }
});

const User = mongoose.model('User', userSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const nodemailer = require('nodemailer');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
// Создаем транспорт для отправки сообщений через SMTP
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'sayzey.74@gmail.com',
        pass: 'ausi awau hylf tgzk'
    }
});


app.post('/register', async (req, res) => {
    try {
        const { username, password, firstName, lastName, age, gender, email } = req.body;
        const newUser = new User({
            username,
            password,
            firstName,
            lastName,
            age,
            gender,
            email
        });
        await newUser.save();
// Сохраняем информацию о пользователе в сессии
req.session.userId = newUser._id;
        // Отправка приветственного сообщения
        await sendWelcomeEmail(email, username);

        res.status(201).json({ message: 'User registered ', redirect: '/login' });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Функция для отправки приветственного электронного письма
async function sendWelcomeEmail(email, username) {
    // Формируем ссылку на страницу localhost:3000/main/:username
    const mainPageURL = `http://localhost:3000/main/${username}`;
    // Конфигурация письма
    const mailOptions = {
        from: 'your-email@gmail.com',
        to: email,
        subject: 'Welcome to Our App',
        text: `Hello ${username},\n\nWelcome to our application! We're glad you joined us. You can access your main page here: ${mainPageURL}`
    };

    // Отправка письма
    await transporter.sendMail(mailOptions);
}



app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid password' });
        }

        // Сохраняем информацию о пользователе в сессии
        req.session.userId = user._id;

        // Перенаправляем на страницу в зависимости от роли
        if (user.role === 'admin') {
            return res.status(200).json({ message: 'Admin login successful', redirect: '/admin/' + user.username });
        } else {
            return res.status(200).json({ message: 'User login successful', redirect: '/main/' + user.username });
        }
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});



app.get('/login', (req, res) => {
    res.render('login');
});

app.get('/register', (req, res) => {
    res.render('register');
});


// Маршрут для страницы /main/Username
app.get('/main/:username', requireLogin, async (req, res) => {
    try {
        const username = req.params.username;
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }
         // Получаем курсы валют
         const currencyRates = await getCurrencyRates();
        const newsArticles = await News.find().sort({ createdAt: -1 });
        if (currencyRates) {
            res.render('main', { user, newsArticles, currencyRates });
        } else {
            // Обрабатываем случай, если не удалось получить курсы валют
            res.status(500).json({ error: 'Failed to fetch currency rates' });
        }
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

app.get('/admin/:username', requireLogin, async (req, res) => {
    try {
        const username = req.params.username;
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Fetch all users except admins
        const users = await User.find({ role: { $ne: 'admin' } });
        const newsArticles = await News.find().sort({ createdAt: -1 });

        res.render('admin', { user, users, newsArticles }); // Pass user data and users list to the view
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});
// Маршрут для получения прогноза погоды
app.get('/weather', async (req, res) => {
    try {
        // Ваш API ключ для OpenWeatherMap
        const apiKey = '9187b5e2fb15999198d20fcc7fd9411d';
        // Город, для которого хотите получить прогноз погоды
        const city = 'Astana'; 
        // Формируем URL для запроса к API
        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

       // Отправляем запрос к OpenWeatherAPI
       const response = await fetch(apiUrl);
       const data = await response.json();

       // Извлекаем необходимые данные о погоде из ответа API
       const weatherData = {
           city: data.name,
           temperature: data.main.temp,
           description: data.weather[0].description,
           humidity: data.main.humidity,
           windSpeed: data.wind.speed,
           iconUrl: `http://openweathermap.org/img/wn/${data.weather[0].icon}.png` // URL для получения иконки погоды
       };

       // Рендерим шаблон EJS с данными о погоде
       res.render('weather', { weather: weatherData });
   } catch (error) {
       console.error('Error fetching weather data:', error);
       res.status(500).send('Error fetching weather data');
   }
});

// DELETE route for user deletion
app.delete('/admin/:username', requireLogin, async (req, res) => {
    try {
        const username = req.params.username;
        // Find the user by username and delete it
        await User.findOneAndDelete({ username });
        res.sendStatus(204); // Send a success status code
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete user' });
    }
});
// PUT route for changing username
app.put('/admin/:username', requireLogin, async (req, res) => {
    try {
        const oldUsername = req.params.username;
        const { newUsername } = req.body;

        // Find the user by old username and update the username
        await User.findOneAndUpdate({ username: oldUsername }, { username: newUsername });
        res.sendStatus(204); // Send a success status code
    } catch (error) {
        res.status(500).json({ error: 'Failed to change username' });
    }
});
// POST route for creating a new admin user
app.post('/admin/create', requireLogin, async (req, res) => {
    try {
        const { newUsername, newPassword, firstName, lastName, age, email, gender } = req.body;

        // Create a new admin user instance
        const newUser = new User({
            username: newUsername,
            password: newPassword,
            firstName,
            lastName,
            age,
            email,
            gender,
            role: 'admin'
        });

        // Save the new admin user to the database
        await newUser.save();   

        res.status(201).json({ message: 'Admin user created successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to create admin user' });
    }
});
app.post('/admin/createNews', requireLogin, async (req, res) => {
    try {
        const { newsTitle, newsContent } = req.body;

        // Создать новую новость
        const newNews = new News({
            title: newsTitle,
            content: newsContent
        });

        // Сохранить новость в базе данных
        await newNews.save();

        res.status(201).json({ message: 'News article created successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to create news article' });
    }
});
app.put('/admin/updateArticle/:id', requireLogin, async (req, res) => {
    try {
        const articleId = req.params.id;
        const { content } = req.body;

        // Найдите статью по ее идентификатору и обновите содержимое
        await News.findByIdAndUpdate(articleId, { content });

        res.status(200).json({ message: 'Article updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update article' });
    }
});


//

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
